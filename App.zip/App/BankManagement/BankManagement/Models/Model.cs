﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankManagement.Models
{
    public class Model
    {

        [Required(ErrorMessage = "Name is Required")]
        public string CustName { get; set; }
        public int CustId { get; set; }
        public string CustGender { get; set; }


        [Required(ErrorMessage = "Email ID is Required")]
        [EmailAddress(ErrorMessage = "Email ID is Not in Proper Format")]
        public string CustEmail { get; set; }


        [Required(ErrorMessage = "Password is Required")]
        public string CustPassword { get; set; }


        [Required(ErrorMessage = "Account Number is Required")]
        public string CustAccount { get; set; }

        public int LoanId { get; set; }
        [Required(ErrorMessage = "Amount is Required")]
        public int Amount { get; set; }

        public int LoanTypeId { get; set; }

        public string LoanStatus { get; set; }

        public string LoanTypeName { get; set; }
        public int ManId { get; set; }
        [Required(ErrorMessage = "Name is Required")]

        public string ManName { get; set; }
        [EmailAddress(ErrorMessage = "Email ID is Not in Proper Format")]

        public string ManEmail { get; set; }

        public string ManPassword { get; set; }
        [Required(ErrorMessage = "Please Select the Role")]
        public string TypeOfUser { get; set; }
        [System.ComponentModel.DataAnnotations.Compare("CustPassword", ErrorMessage = "Password didn't Match")]
        public string CustConPassword { get; set; }

        public List<SelectListItem> List = new List<SelectListItem>();
        public List<Model> ListEmp { get; internal set; }


    }
}