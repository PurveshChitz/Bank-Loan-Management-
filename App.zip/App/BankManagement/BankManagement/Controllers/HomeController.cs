﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using BankManagement.Models;
namespace BankManagement.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            if (ModelState.IsValid)
            { }
            return View();
        }
        [HttpPost]
        public ActionResult Index(Model dat)
        {
			BankManagementEntities2 db = new BankManagementEntities2();
            Customer c = new Customer();
            Manager m = new Manager();
            if (dat.TypeOfUser=="Manager")
            {
                var getdata = db.Managers.FirstOrDefault(n=>n.ManEmail==dat.CustEmail && n.ManPassword==dat.CustPassword);
                if (getdata != null)
                {
                    FormsAuthentication.SetAuthCookie(dat.CustEmail ,false);
                    var authTicket = new FormsAuthenticationTicket(1, getdata.ManName, DateTime.Now, DateTime.Now.AddMinutes(20), false, dat.CustEmail);
                    string encrypt = FormsAuthentication.Encrypt(authTicket);
                    var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encrypt);
                    HttpContext.Response.Cookies.Add(authCookie);
                    Session["ManEmail"] = dat.CustEmail;
                    return RedirectToAction("Display", "BankManager");

                }
                else
                {
                    ViewBag.text = "Invalid EmailID or Password";
                }
            }
            else if (dat.TypeOfUser=="Customer")
            {
                var getdata = db.Customers.FirstOrDefault(n => n.CustEmail == dat.CustEmail && n.CustPassword == dat.CustPassword);
                if (getdata != null)
                {
                    FormsAuthentication.SetAuthCookie(dat.CustEmail, false);
                    var authTicket = new FormsAuthenticationTicket(1, getdata.CustName, DateTime.Now, DateTime.Now.AddMinutes(20), false, dat.CustEmail);
                    string encrypt = FormsAuthentication.Encrypt(authTicket);
                    var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encrypt);
                    HttpContext.Response.Cookies.Add(authCookie);
                    Session["CustEmail"] = dat.CustEmail;
                    return RedirectToAction("Index","BankCustomer");

                }
                else
                {
                    ViewBag.text = "Invalid EmailID or Password";

                }

            }
            return View(dat);
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult SignUp()
        {
            if (ModelState.IsValid)
            { }

            return View();
        }

        [HttpPost]
        public ActionResult SignUp(Model dat)
        {

			BankManagementEntities2 db = new BankManagementEntities2();
            Manager m = new Manager();
            Customer c = new Customer();
            if (dat.TypeOfUser == "Manager")
            {
                if (dat.CustName != null && dat.CustEmail != null && dat.CustPassword != null && dat.CustPassword == dat.CustConPassword)
                {

                    m.ManName = dat.CustName;
                    m.ManEmail = dat.CustEmail;
                    m.ManPassword = dat.CustPassword;
                    db.Managers.Add(m);
                    db.SaveChanges();
                    TempData["msg"] = "<script>alert('Registration succesfully');</script>";
                    return View("Index");
                }
                else
                {
                    ViewBag.Manager = "Please Enter Correct Data";
                }
            }
            else if (dat.TypeOfUser == "Customer")
            {

                if (dat.CustName != null && dat.CustGender != null && dat.CustEmail != null && dat.CustAccount != null && dat.CustPassword != null && dat.CustPassword == dat.CustConPassword)
                {
                    c.CustName = dat.CustName;
                    c.CustGender = dat.CustGender;
                    c.CustEmail = dat.CustEmail;
                    c.CustAccount = dat.CustAccount;
                    c.CustPassword = dat.CustPassword;
                    db.Customers.Add(c);
                    db.SaveChanges();
                    TempData["msg"] = "<script>alert('Registration succesfully');</script>";
                    return View("Index");
                }
                else
                {
                    ViewBag.Manager = "Please Enter Correct Data";
                }
            }
            return View(dat);
        }






    }
}