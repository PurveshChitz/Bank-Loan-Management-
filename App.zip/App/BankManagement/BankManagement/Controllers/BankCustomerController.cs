﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using BankManagement.Models;

namespace BankManagement.Controllers
{
    public class BankCustomerController : Controller
    {
        // GET: BankCustomer
        public ActionResult Index()
        {
			BankManagementEntities2 db = new BankManagementEntities2();
            List<SelectListItem> lst = new List<SelectListItem>();
            Model model = new Model();
            var getdata = db.LoanTypes.ToList();
            Loan loan = new Loan();
            foreach (var item in getdata)
            {
                lst.Add(new SelectListItem
                {
                    Text = item.LoanTypeName,

                    Value = item.LoanTypeId.ToString()

                });
            }
            model.List = lst;

            string Email = Session["CustEmail"].ToString();
            var query = (from c in db.Customers
                         where c.CustEmail == Email
                         select c.CustId).SingleOrDefault();
            loan.CustId = query;



            foreach (var item in db.Loans)
            {
                if (item.LoanStatus=="Pending   ")
                {

                
                if (item.CustId == loan.CustId)
                {
                          return RedirectToAction("DashBoard", "BankCustomer");
                }
                }


            }

            return View(model);           
        }
        [HttpPost]
        public ActionResult Index(Model dat)
        {
			BankManagementEntities2 db = new BankManagementEntities2();
            List<SelectListItem> lst = new List<SelectListItem>();
           //Model model = new Model();
            LoanType loanType = new LoanType();
            Loan loan = new Loan();
            Customer customer = new Customer();
            Model model = new Model();
            var getdata = db.LoanTypes.ToList();
            foreach (var item in getdata)
            {
                lst.Add(new SelectListItem
                {
                    Text = item.LoanTypeName,

                    Value = Convert.ToString(item.LoanTypeId)

                });
            }
            model.List = lst;
            
            loan.Amount = dat.Amount;
            loan.LoanTypeId = dat.LoanTypeId;
            string Email = Session["CustEmail"].ToString();
            // var i = db.Customers.Where(Email.Equals(customer.CustEmail)).Select(customer.CustId);
            var query = (from c in db.Customers
                        where c.CustEmail == Email
                        select c.CustId).SingleOrDefault();
          
            loan.LoanStatus = "Pending";
           // int cid = Convert.ToInt32(Session["CustID"]);
            loan.CustId = query;
            loan.ManId = 1;
            db.Loans.Add(loan);
            db.SaveChanges();
            TempData["msg"] = "<script>alert('Applied SuccessFully');</script>";
            return RedirectToAction("DashBoard","BankCustomer");

           // return View(dat);
        }

        public ActionResult Edit(Model dat)
        {
            //BankManagementEntities db = new BankManagementEntities();
            //Customer c = new Customer();
            //Manager m = new Manager();

            return View();
        }
       
        public ActionResult DashBoard()
        {
			BankManagementEntities2 db = new BankManagementEntities2();
            List<Model> lst = new List<Model>();
            Model objDat = new Model();
            LoanType loanType = new LoanType();
            var getdata1 = db.LoanTypes.ToList();
            Loan loan = new Loan();


            string Email = Session["CustEmail"].ToString();
            var query = (from c in db.Customers
                         where c.CustEmail == Email
                         select c.CustId).SingleOrDefault();
            loan.CustId = query;
            foreach (var item in db.Loans)
            {
                if (item.CustId == loan.CustId)
                {
                    lst.Add(new Model{
                        CustId=item.CustId,
                        LoanId=item.LoanId,
                        //LoanTypeName=item.LoanType.ToString(),
                        LoanStatus=item.LoanStatus
                    });
                    objDat.ListEmp = lst;
                }
                
            }

            return View(objDat);
        }
        


    }
}