﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BankManagement.Models;
namespace BankManagement.Controllers
{
    public class BankManagerController : Controller
    {
        // GET: BankManager
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Display()
        {
			BankManagementEntities2 db = new BankManagementEntities2();
            List<Model> lst = new List<Model>();
            Model model = new Model();
            Loan loan = new Loan();

            var getdata = from e in db.Loans
                          join c in db.LoanTypes
                          on e.LoanTypeId equals c.LoanTypeId
                          join p in db.Customers
                          on e.CustId equals p.CustId
                          into result
                          from p in result.DefaultIfEmpty()
                          select new { e.CustId, p.CustName, e.LoanId, e.LoanTypeId, e.Amount, e.LoanStatus, c.LoanTypeName };
            var getdata1 = db.Loans.Count(m => m.LoanStatus == "Pending");

            if (getdata1 == 0)
            {
                return RedirectToAction("Display0", "BankManager");
            }


            foreach (var item in getdata)
            {
                if (item.LoanStatus == "Pending   ")
                {

                    lst.Add(new Model
                    {
                        LoanId = item.LoanId,
                        LoanTypeName = item.LoanTypeName,
                        LoanStatus = item.LoanStatus,
                        Amount = item.Amount,
                        CustId = item.CustId,
                        CustName = item.CustName


                    });
                    model.ListEmp = lst;
                }
            }

            return View(model);

        }
        //[HttpPost]
        //public ActionResult Display(string id)
        //{
        //    BankManagementEntities db = new BankManagementEntities();
        //    Model dat = new Model();
        //    List<Model> lst = new List<Model>();

        //    var getdata = from e in db.Loans
        //                  join c in db.LoanTypes
        //                  on e.LoanTypeId equals c.LoanTypeId
        //                  join p in db.Customers
        //                  on e.CustId equals p.CustId
        //                  into result
        //                  from p in result.DefaultIfEmpty()
        //                  select new { e.CustId, p.CustName, e.LoanId, e.LoanTypeId, e.Amount, e.LoanStatus, c.LoanTypeName };
        //    if (id == "Accept")
        //    {
        //        foreach (var item in getdata)
        //        {
        //            lst.Add(new Model
        //            {
        //                LoanId = item.LoanId,
        //                LoanTypeName = item.LoanTypeName,
        //                LoanStatus = "Accept",
        //                Amount = item.Amount,
        //                CustId = item.CustId,
        //                CustName = item.CustName


        //            });
        //            dat.ListEmp = lst;
        //        }

        //    }
        //    else if (dat.LoanStatus == "Reject")
        //    {
        //        foreach (var item in getdata)
        //        {
        //            lst.Add(new Model
        //            {
        //                LoanId = item.LoanId,
        //                LoanTypeName = item.LoanTypeName,
        //                LoanStatus = "Reject",
        //                Amount = item.Amount,
        //                CustId = item.CustId,
        //                CustName = item.CustName


        //            });
        //            dat.ListEmp = lst;
        //        }

        //    }


        //    return View(dat);
        //}
        public ActionResult Display0()
        {


            return View();
        }
        
        public ActionResult AcceptControl(int id)
        {
			BankManagementEntities2 db = new BankManagementEntities2();
            Loan loan = new Loan();
            Model dat = new Model();
            List<Model> lst = new List<Model>();

            var getdata1 = db.Loans.Where(m => m.CustId == id);
            foreach (var item in getdata1)
            {
                item.LoanStatus = "Accept";
                
            }
            db.SaveChanges();
           
            return RedirectToAction("Display");
      }
       public ActionResult RejectControl(int id)
      {
			BankManagementEntities2 db = new BankManagementEntities2();
            Loan loan = new Loan();
            Model dat = new Model();
            List<Model> lst = new List<Model>();

            var getdata1 = db.Loans.Where(m => m.CustId == id);
            foreach (var item in getdata1)
            {
                item.LoanStatus = "Reject";
                
            }
            db.SaveChanges();

            return RedirectToAction("Display");


           // return RedirectToAction("Display", "BankManager");
            }
        public ActionResult Approved()
        {

            return View();
        }

        }
    }

